var page = require('webpage').create(),
    fs = require('fs'),
    system = require('system'),
    address, output;
 
if (system.args.length < 3 || system.args.length > 3) 
{
    console.log('Usage: render.js htmlFileName pngFileName');
    phantom.exit(1);
}
else
{
    address = 'file:///' + fs.absolute(system.args[1]);
    output = system.args[2];
    
    page.open(address, function (status) {
        if (status !== 'success') {
            console.log('Unable to load the address: ' + address);
            phantom.exit(1);
        } else {
            window.setTimeout(function () {
                page.render(output);
                phantom.exit();
            }, 200);
        }
    });
}