var page = require('webpage').create(),
    fs = require('fs'),
    system = require('system'),
    address, output;
 
if (system.args.length < 3 || system.args.length > 3) 
{
    console.log('Usage: render.js htmlFileName pngFileName');
    phantom.exit(1);
}
else
{
    address = 'file:///' + fs.absolute(system.args[1]);
    output = system.args[2];
    
    page.open(address, function (status) {
        if (status !== 'success') {
            console.log('Unable to load the address: ' + address);
            phantom.exit(1);
        } else {
		  // being the actual size of the headless browser
		  page.viewportSize = { width: 1440, height: 900 };
		  //console.log(JSON.stringify(document.querySelector('#idSVG').querySelector("g")));
		  //var gees = document.querySelector('#idSVG').querySelectorAll("g");
		  //gees.each(console.log("Got a gee !"));
		  var clipRect = page.evaluate(function(){
		    return document.querySelector('#idSVG').querySelectorAll("g")[3].getBoundingClientRect();
		  });
		console.log([clipRect.top, clipRect.left, clipRect.width, clipRect.height]);
		  page.clipRect = {
		    top:    clipRect.top,
		    left:   clipRect.left,
		    width:  clipRect.width,
		    height: clipRect.height
		  };

		  page.render('idRING.png');
		  phantom.exit();
        }
    });
}