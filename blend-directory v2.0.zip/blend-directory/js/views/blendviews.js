"use strict";

directory.ShellView = Backbone.View.extend({

    initialize: function () {
        this.searchResults = new directory.BlendCollection();
        this.searchresultsView = new directory.BlendListView({model: this.searchResults, className: 'dropdown-menu'});
    },

    render: function () {
        //static, top nav-bar
        this.$el.html(this.template());
        
        //dynamic, search drop-down menu
        $('.navbar-search', this.el).append(this.searchresultsView.render().el);
        return this;
    },

    events: {
        "keyup .search-query": "search",
        "keypress .search-query": "onkeypress"
    },

    search: function (event) {
        console.log(['event: ', event]);

        var key = $('#searchText').val();
        this.searchResults.fetch({reset: true, data: {name: key}});
        var self = this;
        setTimeout(function () {
            $('.dropdown').addClass('open');
        });
    },

    onkeypress: function (event) {
        if (event.keyCode === 13) { // enter key pressed
            event.preventDefault();
        }
    },

    selectMenuItem: function(menuItem) {
        $('.navbar .nav li').removeClass('active');
        if (menuItem) {
            $('.' + menuItem).addClass('active');
        }
    }

});

directory.BlendView = Backbone.View.extend({

    render: function () {
        this.$el.html(this.template(this.model.attributes));
        $('#details', this.el).html(new directory.BlendDetailView({model:this.model}).render().el);
        this.model.reports.fetch({
            success:function (data) {
                if (data.length == 0)
                    $('.no-reports').show();
            }
        });
        $('#reports', this.el).append(new directory.BlendListView({model:this.model.reports}).render().el);
        return this;
    }
});

directory.BlendDetailView = Backbone.View.extend({

    initialize:function () {
        this.model.on("change", this.render, this);
    },

    render:function () {
        this.$el.html(this.template(this.model.attributes));
        return this;
    }

});

directory.BlendSummaryView = Backbone.View.extend({
    initialize: function () {
        this.summaryResults = new directory.BlendCollection();
        
        //fetch() calls sync(read) of BlendCollection().
        this.summaryResults.fetch({reset: true, data: {name: ''}});
        
        console.log(this.summaryResults);
    },

    render: function () {
        //static, div with a header.
        this.$el.html(this.template());
        
        //Dynamic, paginated summary.
        $('#summary', this.el).append(new directory.BlendPanelView({model:this.summaryResults}).render().el);

        return this;
    }
});
