// http://blog.thomsonreuters.com/index.php/mobile-patent-suits-graphic-of-the-day/
var links = [
  { source: "RxFeedDrumLvl", target: "MV:Feed", clgain: "-1.2" },
  { source: "IORatio", target: "MV:FreshiC4", clgain: "3.2" },
  { source: "FeedDrumLvl", target: "MV:Feed", clgain: "-3.8" },
  { source: "BtmsIC4", target: "MV:FreshiC4", clgain: "0.7" },
  { source: "BtmsIC4", target: "MV:BtmsTC", clgain: "-2.0" },
  { source: "BtmsIC4", target: "MV:Reflux", clgain: "0.6" },
  { source: "BtmsIC4", target: "MV:Recycle", clgain: "-0.8" },
  { source: "BtmsIC4", target: "OvhdNC4", clgain: "-0.6" },
  { source: "BtmsIC4", target: "BoilUp", clgain: "0.6" },
  { source: "BtmsIC4", target: "TopTemp", clgain: "-0.4" },
  { source: "BtmsIC4", target: "BtmsPCT", clgain: "-1.5" },
  { source: "BtmsIC4", target: "BtmsTemp", clgain: "-4.0" },
  { source: "BtmsIC4", target: "StmOP", clgain: "-2.2" },
  { source: "BtmsIC4", target: "BtmsOP", clgain: "-2.0" },
  { source: "OvhdDT", target: "MV:Reflux", clgain: "-0.2" },
  { source: "OvhdDT", target: "OvhdNC4", clgain: "0.02" },
  { source: "OvhdDT", target: "BoilUp", clgain: "-0.2" },
  { source: "Purge", target: "MV:FreshiC4", clgain: "0.9" },
  { source: "Purge", target: "MV:Reflux", clgain: "1.0" },
  { source: "Purge", target: "MV:Recycle", clgain: "-1.0" },
  { source: "Purge", target: "OvhdNC4", clgain: "0.1" },
  { source: "Purge", target: "BoilUp", clgain: "1.0" },
  { source: "MV:Pr", target: "MV:FreshiC4", clgain: "0.2" },
  { source: "MV:Pr", target: "MV:BtmsTC", clgain: "0.7" },
  { source: "MV:Pr", target: "MV:Reflux", clgain: "0.7" },
  { source: "MV:Pr", target: "MV:Recycle", clgain: "-0.2" },
  { source: "MV:Pr", target: "OvhdNC4", clgain: "-0.1" },
  { source: "MV:Pr", target: "BoilUp", clgain: "0.7" },
  { source: "MV:Pr", target: "TopTemp", clgain: "0.1" },
  { source: "MV:Pr", target: "BtmsPCT", clgain: "0.5" },
  { source: "MV:Pr", target: "BtmsTemp", clgain: "-0.2" },
  { source: "MV:Pr", target: "StmOP", clgain: "0.8" },
  { source: "MV:Pr", target: "BtmsOP", clgain: "0.7" }
];
/*
var links = [
  { source: "CV:RxFeedDrumLvl", target: "DiBFeed", clgain: "-1.2" },
  { source: "CV:IORatio", target: "FreshiC4", clgain: "3.2" },
  { source: "CV:DibFeedDrumLvl", target: "DiBFeed", clgain: "-3.8" },
  { source: "CV:DiBBtmsIC4", target: "FreshiC4", clgain: "0.7" },
  { source: "CV:DiBBtmsIC4", target: "DiBBtmsTC", clgain: "-2.0" },
  { source: "CV:DiBBtmsIC4", target: "DiBReflux", clgain: "0.6" },
  { source: "CV:DiBBtmsIC4", target: "DiBRecycle", clgain: "-0.8" },
  { source: "CV:DiBBtmsIC4", target: "DiBOvhdNC4", clgain: "-0.6" },
  { source: "CV:DiBBtmsIC4", target: "DiBBoilUp", clgain: "0.6" },
  { source: "CV:DiBBtmsIC4", target: "DiBTopTemp", clgain: "-0.4" },
  { source: "CV:DiBBtmsIC4", target: "DiBBtmsPCT", clgain: "-1.5" },
  { source: "CV:DiBBtmsIC4", target: "DiBBtmsTemp", clgain: "-4.0" },
  { source: "CV:DiBBtmsIC4", target: "DiBStmOP", clgain: "-2.2" },
  { source: "CV:DiBBtmsIC4", target: "DiBBtmsOP", clgain: "-2.0" },
  { source: "CV:DiBOvhdDT", target: "DiBReflux", clgain: "-0.2" },
  { source: "CV:DiBOvhdDT", target: "DiBOvhdNC4", clgain: "0.02" },
  { source: "CV:DiBOvhdDT", target: "DiBBoilUp", clgain: "-0.2" },
  { source: "CV:DiBPurge", target: "FreshiC4", clgain: "0.9" },
  { source: "CV:DiBPurge", target: "DiBReflux", clgain: "1.0" },
  { source: "CV:DiBPurge", target: "DiBRecycle", clgain: "-1.0" },
  { source: "CV:DiBPurge", target: "DiBOvhdNC4", clgain: "0.1" },
  { source: "CV:DiBPurge", target: "DiBBoilUp", clgain: "1.0" },
  { source: "CV:DC4OvhdC5", target: "DC4Reflux", clgain: "-0.3" },
  { source: "CV:DC4OvhdC5", target: "DC4btmsTC", clgain: "-0.9" },
  { source: "CV:DC4OvhdC5", target: "DC4TopPCT", clgain: "2.0" },
  { source: "CV:DC4OvhdC5", target: "DC4OvhdPr", clgain: "-1.9" },
  { source: "CV:DC4OvhdC5", target: "DC4btmsPCT", clgain: "-1.2" },
  { source: "CV:DC4BtmsC4", target: "DC4Reflux", clgain: "-0.4" },
  { source: "CV:DC4BtmsC4", target: "DC4btmsTC", clgain: "-5.5" },
  { source: "CV:DC4BtmsC4", target: "DC4TopPCT", clgain: "2.8" },
  { source: "CV:DC4BtmsC4", target: "DC4OvhdPr", clgain: "-2.6" },
  { source: "CV:DC4BtmsC4", target: "DC4btmsPCT", clgain: "-7.3" },
  { source: "MV:DiBPr", target: "FreshiC4", clgain: "0.2" },
  { source: "MV:DiBPr", target: "DiBBtmsTC", clgain: "0.7" },
  { source: "MV:DiBPr", target: "DiBReflux", clgain: "0.7" },
  { source: "MV:DiBPr", target: "DiBRecycle", clgain: "-0.2" },
  { source: "MV:DiBPr", target: "DiBOvhdNC4", clgain: "-0.1" },
  { source: "MV:DiBPr", target: "DiBBoilUp", clgain: "0.7" },
  { source: "MV:DiBPr", target: "DiBTopTemp", clgain: "0.1" },
  { source: "MV:DiBPr", target: "DiBBtmsPCT", clgain: "0.5" },
  { source: "MV:DiBPr", target: "DiBBtmsTemp", clgain: "-0.2" },
  { source: "MV:DiBPr", target: "DiBStmOP", clgain: "0.8" },
  { source: "MV:DiBPr", target: "DiBBtmsOP", clgain: "0.7" }
];
*/
var matrix = [],
    groups = [],
    nodeIndex = {},
    id = 0,
    nodes = {};

// Compute the distinct nodes from the links.
links.forEach(function (link) {
    nodes[link.source] || (nodes[link.source] = 1);
    nodes[link.target] || (nodes[link.target] = 1);
});

nodes = d3.keys(nodes);
nodes.sort();
nodes.forEach(function (node) {
    if (!(node in nodeIndex)) {
        nodeIndex[node] = id++;
    }
});

for (var node in nodeIndex) {
    var targets = matrix[nodeIndex[node]] = [];
    targets.name = node;
    for (var targetNode in nodeIndex) {
        targets[nodeIndex[targetNode]] = node === targetNode ? 1 : 0;
    }
}

links.forEach(function (link) {
    matrix[nodeIndex[link.source]][nodeIndex[link.target]] = 1;
    matrix[nodeIndex[link.target]][nodeIndex[link.source]] = 1;
});

var cluster = science.stats.hcluster();

var rows = [];

traverse(cluster(matrix), rows);

rows.forEach(function (node, i) {
    nodeIndex[groups[i] = node.centroid.name] = i;
    matrix[i] = [];
    matrix[i].node = node;
    for (var j = 0; j < rows.length; j++) matrix[i][j] = 0;
});

links.forEach(function (link) {
    matrix[nodeIndex[link.source]][nodeIndex[link.target]]++;
    matrix[nodeIndex[link.target]][nodeIndex[link.source]]++;
});

function traverse(tree, rows) {
    if (tree.left) traverse(tree.left, rows);
    if (tree.right) traverse(tree.right, rows);
    if (tree.centroid.name) rows.push(tree);
}

var distance = science.stats.distance.euclidean;

var chord = d3.layout.chord()
  .padding(.05)
  .matrix(matrix);

chord.matrix(matrix);

var w = 960,
    h = 600,
    p = 40,
    r0 = Math.min(w, h) * .41,
    r1 = r0 * 1.1;

var fill = d3.scale.category20b();

var svg = d3.select("#vis")
  .append("svg")
    .attr("width", w + p + p)
    .attr("height", h + p + p)
  .append("g")
    .attr("transform", "translate(" + (w / 2 + p) + "," + (h / 2 + p) + ")");

var g = svg.selectAll("g.group")
    .data(chord.groups)
  .enter().append("g")
    .attr("class", "group");

g.append("path")
    .style("fill", function (d) { return fill(d.index); })
    .attr("d", d3.svg.arc().innerRadius(r0).outerRadius(r1))
    .on("mouseover", fade(.1))
    .on("mouseout", fade(1));

g.append("text")
    .each(function (d) { d.angle = (d.startAngle + d.endAngle) / 2; })
    .attr("dy", ".35em")
    .attr("text-anchor", function (d) {
        return d.angle > Math.PI ? "end" : null;
    })
    .attr("transform", function (d) {
        return "rotate(" + (d.angle * 180 / Math.PI - 90) + ")"
            + "translate(" + (r0 + 32) + ")"
            + (d.angle > Math.PI ? "rotate(180)" : "");
    })
    .text(function (d) { return groups[d.index]; });

svg.append("g")
    .attr("class", "chord")
  .selectAll("path")
    .data(function () {
        var chords = [];
        chord.chords().forEach(function (chord) {
            chords.push(chord);
            if (chord.source.value === 2) {
                var delta = (chord.source.endAngle - chord.source.startAngle) / 2,
                    delta2 = (chord.target.endAngle - chord.target.startAngle) / 2;
                chords.push({
                    source: {
                        startAngle: chord.target.startAngle,
                        endAngle: chord.target.endAngle - delta,
                        index: chord.target.index,
                        subindex: chord.target.subindex,
                        value: 1
                    }, target: {
                        startAngle: chord.source.startAngle + delta2,
                        endAngle: chord.source.endAngle,
                        index: chord.source.index,
                        subindex: chord.source.subindex,
                        value: 1
                    }
                });
                chord.target.startAngle += delta;
                chord.source.endAngle -= delta2;
            }
        });
        return chords;
    })
  .enter().append("path")
    .style("fill", function (d) { return fill(d.source.subindex); })
    .attr("d", d3.svg.chord().radius(r0))
    .style("opacity", 1);

/** Returns an event handler for fading a given chord group. */
function fade(opacity) {
    return function (g) {
        svg.selectAll("g.chord path")
            .filter(function (d) {
                return d.source.index != g.index && d.target.index != g.index;
            })
          .transition()
            .style("opacity", opacity);
    };
}
